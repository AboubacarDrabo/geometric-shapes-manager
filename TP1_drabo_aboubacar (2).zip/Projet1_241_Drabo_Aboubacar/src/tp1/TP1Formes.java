/**
 * Nom : Drabo Aboubacar
 * Cours : 420-241-AH
 * Dernière modification : 12 mars 2026
 * Description : Classe TP1Formes 
 */

package tp1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TP1Formes extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel paneau_principal;
	private Polygone formeChargee;
	private JComboBox boxformeChargee;
	private JLabel lblLongueur;
	private JLabel lblLargeur;
	private JLabel lblPeri;
	private JLabel lblAire;
	private JButton btnCharger;
	private JButton btnCalculer;
	private JTextField txtLongueur;
	private JTextField txtLargeur;
	private JTextField txtPeri;
	private JTextField txtAire;
	private JLabel lblFormeChargee;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TP1Formes frame = new TP1Formes();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public TP1Formes() {

		setTitle("241 - TP1 - Drabo, Aboubacar");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 521, 328);
		paneau_principal = new JPanel();
		paneau_principal.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(paneau_principal);
		paneau_principal.setLayout(null);

		JLabel lblpresentation = new JLabel("Ce programme sert a calculer l'aire et le perimetre d'une forme");
		lblpresentation.setBounds(10, 10, 390, 23);
		paneau_principal.add(lblpresentation);

		JLabel lblTxtForme = new JLabel("Choisir la forme a creer");
		lblTxtForme.setBounds(45, 43, 174, 23);
		paneau_principal.add(lblTxtForme);

		String[] tableauDeFormes = { "Cercle", "Carre", "Rectangle", "Hexagone" };
		boxformeChargee = new JComboBox(tableauDeFormes);
		boxformeChargee.addActionListener(new BoxformeChargeeActionListener());
		boxformeChargee.setBounds(45, 69, 137, 20);
		paneau_principal.add(boxformeChargee);

		lblLongueur = new JLabel("Longueur");
		lblLongueur.setBounds(28, 133, 104, 23);
		paneau_principal.add(lblLongueur);

		txtLongueur = new JTextField();
		txtLongueur.setBounds(109, 135, 110, 18);
		paneau_principal.add(txtLongueur);
		txtLongueur.setColumns(10);

		lblLargeur = new JLabel("Largeur");
		lblLargeur.setBounds(28, 165, 104, 23);
		paneau_principal.add(lblLargeur);

		txtLargeur = new JTextField();
		txtLargeur.setBounds(109, 180, 110, 18);
		paneau_principal.add(txtLargeur);
		txtLargeur.setColumns(10);

		lblLargeur.setVisible(false);
		txtLargeur.setVisible(false);
		lblLongueur.setText("Rayon");

		btnCharger = new JButton("Charger");
		btnCharger.addActionListener(new BtnChargerActionListener());
		btnCharger.setBounds(75, 233, 107, 20);
		paneau_principal.add(btnCharger);

		btnCalculer = new JButton("Calculer");
		btnCalculer.addActionListener(new BtnCalculerActionListener());
		btnCalculer.setBounds(364, 134, 84, 20);
		paneau_principal.add(btnCalculer);

		lblPeri = new JLabel("Perimetre");
		lblPeri.setBounds(269, 183, 104, 23);
		paneau_principal.add(lblPeri);

		txtPeri = new JTextField();
		txtPeri.setColumns(10);
		txtPeri.setBounds(366, 188, 110, 18);
		txtPeri.setEditable(false);
		paneau_principal.add(txtPeri);

		lblAire = new JLabel("Aire");
		lblAire.setBounds(269, 216, 104, 23);
		paneau_principal.add(lblAire);

		txtAire = new JTextField();
		txtAire.setColumns(10);
		txtAire.setBounds(364, 218, 110, 18);
		txtAire.setEditable(false);
		paneau_principal.add(txtAire);

		lblFormeChargee = new JLabel("Aucune forme chargée");
		lblFormeChargee.setBounds(327, 111, 149, 13);
		paneau_principal.add(lblFormeChargee);

	}

	// COMBOX BOX
	private class BoxformeChargeeActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String choix = (String) boxformeChargee.getSelectedItem();

			if (choix.equals("Cercle")) {
				lblLongueur.setVisible(true);
				lblLargeur.setVisible(false);
				txtLargeur.setVisible(false);
				lblLongueur.setText("Rayon");
			} else if (choix.equals("Carre")) {
				lblLongueur.setVisible(true);
				lblLargeur.setVisible(false);
				txtLargeur.setVisible(false);
				lblLongueur.setText("Cote");
			} else if (choix.equals("Rectangle")) {
				lblLongueur.setVisible(true);
				lblLargeur.setVisible(true);
				lblLongueur.setText("Longueur");
				lblLargeur.setText("Largeur");
				txtLargeur.setVisible(true);
			} else if (choix.equals("Hexagone")) {
				lblLongueur.setVisible(true);
				lblLargeur.setVisible(false);
				txtLargeur.setVisible(false);
				lblLongueur.setText("Cote");
			}
		}
	}

	// BOUTON CHARGER
	private class BtnChargerActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			String choix = (String) boxformeChargee.getSelectedItem();

			try {
				double v1 = Double.parseDouble(txtLongueur.getText());

				if (v1 <= 0) {

					JOptionPane.showMessageDialog(null, "Oups. Erreur d'entrée de nombres!");
					return;
				}

				if (choix.equals("Cercle")) {
					formeChargee = new Cercle(v1);
					lblFormeChargee.setText(formeChargee.toString());

				} else if (choix.equals("Carre")) {
					formeChargee = new Carre(v1);
					lblFormeChargee.setText(formeChargee.toString());
				} else if (choix.equals("Rectangle")) {
					double v2 = Double.parseDouble(txtLargeur.getText());
					if (v2 <= 0) {
						JOptionPane.showMessageDialog(null, "Oups. Erreur d'entrée de nombres!");
						return;
					}
					formeChargee = new Rectangle(v1, v2);
					lblFormeChargee.setText(formeChargee.toString());
				} else if (choix.equals("Hexagone")) {
					formeChargee = new Hexagone(v1);
					lblFormeChargee.setText(formeChargee.toString());
				}

			} catch (Exception ex) {
				JOptionPane.showMessageDialog(null, "Oups. Erreur d'entrée de nombres!");
			}
		}
	}

	// BOUTON CALCULER
	private class BtnCalculerActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			if (formeChargee == null) {
				JOptionPane.showMessageDialog(null, "Oups. Pas de forme chargée valide!");
			} else {
				txtAire.setText(String.format("%.2f", formeChargee.aire()));
				txtPeri.setText(String.format("%.2f", formeChargee.perimetre()));
			}

		}
	}
}