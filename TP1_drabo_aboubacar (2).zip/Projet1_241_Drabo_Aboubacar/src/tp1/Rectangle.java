/**
 * Nom : Drabo Aboubacar
 * Cours : 420-241-AH
 * Dernière modification : 12 mars 2026
 * Description : Classe enfant représentant un Rectangle
 */

package tp1;

public class Rectangle extends Polygone {

	// ATTRIBUTS
	public double longueur() {
		return super.getVal1();
	}

	public double largeur() {
		return super.getVal2();
	}

	// CONSTRUCTEUR
	public Rectangle(double val1, double val2) {
		super(val1, val2);
	}

	// METHODES

	@Override
	// AIRE
	public double aire() {
		return longueur() * largeur();
	}

	@Override
	// PERIMETRE
	public double perimetre() {
		return 2 * (largeur() + longueur());
	}

	@Override
	public String toString() {
		return "Rectangle [" + longueur() + " , " + largeur() +"]";
	}

}
